# Keep AccessibilityService entry points and model classes.
-keep class com.example.gamezopeofflineauto.GameAutomationService { *; }
-keep class com.example.gamezopeofflineauto.AutomationEngine { *; }
