package com.example.gamezopeofflineauto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.ColorSpace
import android.graphics.Path
import android.hardware.HardwareBuffer
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.Executors

class GameAutomationService : AccessibilityService() {
    private var lastAction = 0L
    private val executor = Executors.newSingleThreadExecutor()

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!AutomationEngine.running || Build.VERSION.SDK_INT < 30) return
        val now = System.currentTimeMillis()
        if (now - lastAction < AutomationEngine.actionGapMs()) return
        lastAction = now

        // First handle accessible text/buttons, then use offline vision for Fruity Fiesta.
        AutomationEngine.inspect(rootInActiveWindow)?.let { dispatch(it); return }
        takeScreenshot(displayId, executor, object : TakeScreenshotCallback() {
            override fun onSuccess(screenshot: ScreenshotResult) {
                val buffer = screenshot.hardwareBuffer
                val bitmap = try {
                    Bitmap.wrapHardwareBuffer(buffer, ColorSpace.get(ColorSpace.Named.SRGB))?.copy(Bitmap.Config.ARGB_8888, false)
                } finally { buffer.close() }
                if (bitmap != null) {
                    val decision = FruityFiestaVision.decide(bitmap)
                    bitmap.recycle()
                    if (decision != null && AutomationEngine.running) {
                        dispatchSwipe(decision.startX, decision.startY, decision.targetX, decision.startY, 280L)
                    }
                }
            }
            override fun onFailure(errorCode: Int) { }
        })
    }

    private fun dispatch(action: AutomationEngine.Action) {
        when (action) {
            is AutomationEngine.Action.Tap -> dispatchTap(action.x, action.y)
            is AutomationEngine.Action.Swipe -> dispatchSwipe(action.x1, action.y1, action.x2, action.y2, action.durationMs)
        }
    }

    private fun dispatchTap(x: Int, y: Int) {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 50)).build()
        dispatchGesture(gesture, callback(), null)
    }

    private fun dispatchSwipe(x1: Int, y1: Int, x2: Int, y2: Int, duration: Long) {
        val path = Path().apply { moveTo(x1.toFloat(), y1.toFloat()); lineTo(x2.toFloat(), y2.toFloat()) }
        val adjusted = (duration / AutomationEngine.speed).toLong().coerceAtLeast(80L)
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, adjusted)).build()
        dispatchGesture(gesture, callback(), null)
    }

    private fun callback() = object : GestureResultCallback() {
        override fun onCompleted(gesture: GestureDescription?) { AutomationEngine.markAction() }
    }

    override fun onInterrupt() {}
    override fun onDestroy() { executor.shutdownNow(); super.onDestroy() }
}
