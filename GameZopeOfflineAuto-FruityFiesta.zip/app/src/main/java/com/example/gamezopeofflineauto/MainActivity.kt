package com.example.gamezopeofflineauto

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var stats: TextView
    private lateinit var speedLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
        }

        val title = TextView(this).apply {
            text = getString(R.string.app_name)
            textSize = 25f
        }
        val subtitle = TextView(this).apply {
            text = "Offline • On-device • Rule based"
            textSize = 14f
        }
        status = TextView(this).apply {
            text = "Status: STOPPED"
            textSize = 17f
        }
        stats = TextView(this).apply {
            textSize = 15f
            text = AutomationEngine.statsText()
        }

        speedLabel = TextView(this).apply { text = "Speed: 1.0×" }
        val speed = SeekBar(this).apply {
            max = 190
            progress = 90
        }
        speed.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val value = 0.1f + p / 100f
                AutomationEngine.speed = value
                speedLabel.text = String.format(Locale.US, "Speed: %.1f×", value)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        fun button(label: String, action: () -> Unit) = Button(this).apply {
            text = label
            setOnClickListener { action() }
        }

        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(status)
        layout.addView(speedLabel)
        layout.addView(speed)

        layout.addView(button("1. Enable Accessibility Service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        layout.addView(button("2. START") {
            AutomationEngine.start()
            status.text = "Status: RUNNING"
        })
        layout.addView(button("PAUSE") {
            AutomationEngine.pause()
            status.text = "Status: PAUSED"
        })
        layout.addView(button("STOP / RESET") {
            AutomationEngine.stop()
            status.text = "Status: STOPPED"
            stats.text = AutomationEngine.statsText()
        })
        layout.addView(button("RECORD / REPLAY") {
            Toast.makeText(this, "Local recorder/replay framework is ready for game-specific actions.", Toast.LENGTH_LONG).show()
        })
        layout.addView(stats)

        setContentView(layout)
        AutomationEngine.onStats = { runOnUiThread { stats.text = AutomationEngine.statsText() } }
    }
}
