package com.example.gamezopeofflineauto

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Offline, heuristic vision for the Gamezop Fruity Fiesta canvas.
 * It does not use network, OCR, cloud APIs, or external ML services.
 */
object FruityFiestaVision {
    data class Fruit(val x: Int, val y: Int, val radius: Int, val rgb: Int, val area: Int)
    data class Decision(val startX: Int, val startY: Int, val targetX: Int, val confidence: Float)

    fun decide(screen: Bitmap): Decision? {
        if (screen.width < 300 || screen.height < 500) return null
        val scale = min(1f, 360f / screen.width)
        val w = max(1, (screen.width * scale).toInt())
        val h = max(1, (screen.height * scale).toInt())
        val small = if (w != screen.width) Bitmap.createScaledBitmap(screen, w, h, true) else screen

        // Gamezop mobile canvas is normally centered. Ignore browser/system bars.
        val left = (w * 0.05f).toInt()
        val right = (w * 0.95f).toInt()
        val top = (h * 0.15f).toInt()
        val bottom = (h * 0.86f).toInt()
        val minArea = max(12, (w * h * 0.00008f).toInt())

        val visited = BooleanArray(w * h)
        val fruits = ArrayList<Fruit>()
        val qx = IntArray(w * h / 8 + 32)
        val qy = IntArray(qx.size)

        fun idx(x: Int, y: Int) = y * w + x
        fun colorful(c: Int): Boolean {
            val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
            val mx = max(r, max(g, b)); val mn = min(r, min(g, b))
            return mx > 105 && (mx - mn) > 45 && !(r > 205 && g > 175 && b < 150 && abs(r - g) < 55)
        }

        for (y in top until bottom step 2) {
            for (x in left until right step 2) {
                val i = idx(x, y)
                if (visited[i] || !colorful(small.getPixel(x, y))) continue
                var head = 0; var tail = 0
                qx[tail] = x; qy[tail] = y; tail++
                visited[i] = true
                var sx = 0L; var sy = 0L; var area = 0; var minX = x; var maxX = x; var minY = y; var maxY = y
                var sr = 0L; var sg = 0L; var sb = 0L
                while (head < tail && tail < qx.size) {
                    val cx = qx[head]; val cy = qy[head]; head++
                    val c = small.getPixel(cx, cy)
                    sx += cx; sy += cy; area++
                    sr += Color.red(c); sg += Color.green(c); sb += Color.blue(c)
                    minX = min(minX, cx); maxX = max(maxX, cx); minY = min(minY, cy); maxY = max(maxY, cy)
                    val ns = intArrayOf(-2, 0, 2, 0)
                    val nt = intArrayOf(0, -2, 0, 2)
                    for (k in 0..3) {
                        val nx = cx + ns[k]; val ny = cy + nt[k]
                        if (nx < left || nx >= right || ny < top || ny >= bottom) continue
                        val ni = idx(nx, ny)
                        if (!visited[ni] && colorful(small.getPixel(nx, ny))) {
                            visited[ni] = true
                            if (tail < qx.size) { qx[tail] = nx; qy[tail] = ny; tail++ }
                        }
                    }
                }
                val bw = maxX - minX + 1; val bh = maxY - minY + 1
                if (area >= minArea && bw in 5..(w / 2) && bh in 5..(h / 2)) {
                    val cx = (sx / area).toInt(); val cy = (sy / area).toInt()
                    val rgb = Color.rgb((sr / area).toInt(), (sg / area).toInt(), (sb / area).toInt())
                    fruits += Fruit(cx, cy, max(bw, bh) / 2, rgb, area)
                }
            }
        }

        if (small !== screen) small.recycle()
        if (fruits.isEmpty()) return null

        // Current fruit is usually the colorful object nearest the top-center of the play bin.
        val centerX = w / 2
        val current = fruits.filter { it.y < top + (bottom - top) * 0.34f }
            .minByOrNull { abs(it.x - centerX) + it.y * 0.35 } ?: return null

        val lower = fruits.filter { it.y > current.y + max(8, current.radius / 2) }
        val same = lower.minByOrNull { colorDistance(it.rgb, current.rgb) }
        val targetSmallX = when {
            same != null && colorDistance(same.rgb, current.rgb) < 115 -> same.x
            else -> chooseOpenColumn(lower, w)
        }
        val targetX = (targetSmallX / scale).toInt().coerceIn((screen.width * 0.12f).toInt(), (screen.width * 0.88f).toInt())
        val startX = (current.x / scale).toInt()
        val startY = (current.y / scale).toInt()
        val confidence = if (same != null) 0.85f else 0.55f
        return Decision(startX, startY, targetX, confidence)
    }

    private fun colorDistance(a: Int, b: Int): Int {
        return abs(Color.red(a) - Color.red(b)) + abs(Color.green(a) - Color.green(b)) + abs(Color.blue(a) - Color.blue(b))
    }

    private fun chooseOpenColumn(fruits: List<Fruit>, w: Int): Int {
        if (fruits.isEmpty()) return w / 2
        val bins = 8
        val score = IntArray(bins)
        for (f in fruits) {
            val b = (f.x * bins / w).coerceIn(0, bins - 1)
            score[b] += max(1, f.radius)
        }
        var best = 0
        for (i in 1 until bins) if (score[i] < score[best]) best = i
        return ((best + 0.5f) * w / bins).toInt()
    }
}
