# GameZopeOfflineAuto — Fruity Fiesta

This version is targeted at **Gamezop Fruity Fiesta**. Fruity Fiesta is a fruit-drop/merge game: fruits are dropped into a container and identical fruits merge into larger fruits. The app uses Android AccessibilityService gestures and **offline screenshot analysis**; it does not require INTERNET permission.

## What this build adds
- Fruity Fiesta-specific offline vision heuristic.
- Detects colorful fruit blobs from an accessibility screenshot.
- Estimates the currently falling fruit and chooses a target column based on color matching / open space.
- Sends a horizontal drag gesture to place the fruit.
- Start / Pause / Stop and speed controls remain in the app.

## Important
This is a heuristic automation engine, not a guaranteed solver. Gamezop may change the canvas, physics, UI, or layout, so testing and tuning on the user's device may be necessary. Use automation only where you are authorized to do so and where it does not bypass anti-cheat or access controls.

## Build
Use the included GitHub Actions workflow at `.github/workflows/build-apk.yml` to build an installable release APK from GitHub.
