package com.example.gamezopeofflineauto

import android.view.accessibility.AccessibilityNodeInfo

object AutomationEngine {
    @Volatile var speed = 1.0f
    @Volatile var running = false

    private var startedAt = 0L
    private var actions = 0
    private var detections = 0
    var onStats: (() -> Unit)? = null

    data class Rule(
        val name: String,
        val textContains: String? = null,
        val descriptionContains: String? = null,
        val action: Action
    )

    sealed class Action {
        data class Tap(val x: Int, val y: Int) : Action()
        data class Swipe(
            val x1: Int, val y1: Int,
            val x2: Int, val y2: Int,
            val durationMs: Long
        ) : Action()
    }

    // Replace these examples with rules for a game you are authorized to automate.
    val rules = mutableListOf(
        Rule("Example Start", textContains = "Start", action = Action.Tap(540, 1500)),
        Rule("Example Continue", textContains = "Continue", action = Action.Tap(540, 1500))
    )

    fun start() {
        if (!running) {
            if (startedAt == 0L) startedAt = System.currentTimeMillis()
            running = true
            onStats?.invoke()
        }
    }

    fun pause() {
        running = false
        onStats?.invoke()
    }

    fun stop() {
        running = false
        startedAt = 0L
        actions = 0
        detections = 0
        onStats?.invoke()
    }

    fun statsText(): String {
        val duration = if (startedAt == 0L) 0L
        else (System.currentTimeMillis() - startedAt) / 1000L
        return "Actions: $actions\nDuration: ${duration}s\nDetected states: $detections"
    }

    fun inspect(root: AccessibilityNodeInfo?): Action? {
        if (!running || root == null) return null
        for (rule in rules) {
            if (matches(root, rule)) {
                detections++
                onStats?.invoke()
                return rule.action
            }
        }
        return null
    }

    private fun matches(root: AccessibilityNodeInfo, rule: Rule): Boolean {
        val nodes = ArrayList<AccessibilityNodeInfo>()
        collect(root, nodes)
        return nodes.any { n ->
            val text = n.text?.toString() ?: ""
            val desc = n.contentDescription?.toString() ?: ""
            (rule.textContains == null || text.contains(rule.textContains, true)) &&
            (rule.descriptionContains == null || desc.contains(rule.descriptionContains, true))
        }
    }

    private fun collect(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>) {
        out.add(node)
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { collect(it, out) }
        }
    }

    fun markAction() {
        actions++
        onStats?.invoke()
    }
}
