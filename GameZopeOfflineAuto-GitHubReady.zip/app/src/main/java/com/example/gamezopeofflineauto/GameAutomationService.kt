package com.example.gamezopeofflineauto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class GameAutomationService : AccessibilityService() {
    private var lastAction = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!AutomationEngine.running) return

        val now = System.currentTimeMillis()
        val minGap = (250L / AutomationEngine.speed)
            .toLong().coerceAtLeast(40L)
        if (now - lastAction < minGap) return

        val action = AutomationEngine.inspect(rootInActiveWindow) ?: return
        lastAction = now

        when (action) {
            is AutomationEngine.Action.Tap ->
                dispatchTap(action.x, action.y)
            is AutomationEngine.Action.Swipe ->
                dispatchSwipe(action.x1, action.y1, action.x2, action.y2, action.durationMs)
        }
    }

    private fun dispatchTap(x: Int, y: Int) {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            .build()
        dispatchGesture(gesture, callback(), null)
    }

    private fun dispatchSwipe(x1: Int, y1: Int, x2: Int, y2: Int, duration: Long) {
        val path = Path().apply {
            moveTo(x1.toFloat(), y1.toFloat())
            lineTo(x2.toFloat(), y2.toFloat())
        }
        val adjusted = (duration / AutomationEngine.speed)
            .toLong().coerceAtLeast(50L)
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, adjusted))
            .build()
        dispatchGesture(gesture, callback(), null)
    }

    private fun callback() = object : GestureResultCallback() {
        override fun onCompleted(gesture: GestureDescription?) {
            AutomationEngine.markAction()
        }
    }

    override fun onInterrupt() {}
}
