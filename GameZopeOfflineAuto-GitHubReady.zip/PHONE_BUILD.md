# Build the APK using only an Android phone

1. Create/open your GitHub repository.
2. Upload the contents of this ZIP so that `app/`, `build.gradle.kts`, and `settings.gradle.kts`
   are at the repository root.
3. Make sure `.github/workflows/build-apk.yml` is also uploaded.
4. Open **Actions** in GitHub.
5. Select **Build Installable APK**.
6. Tap **Run workflow**.
7. Wait for the green checkmark.
8. Open the completed workflow and scroll to **Artifacts**.
9. Download **GameZopeOfflineAuto-APK**.
10. Extract the artifact if GitHub downloaded it as a ZIP, then tap
    `GameZopeOfflineAuto.apk` to install.

The workflow creates a temporary signing key only for this build so the APK can be
installed. Keep your own permanent release keystore if you later publish the app.
