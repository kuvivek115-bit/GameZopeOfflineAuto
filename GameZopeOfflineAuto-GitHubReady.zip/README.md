# GameZopeOfflineAuto — Release-ready Android project

## Features
- Native Kotlin Android app
- Offline-only architecture: no INTERNET permission
- AccessibilityService for authorized UI automation
- Automatic UI state matching through accessibility text/content descriptions
- Tap and swipe gestures
- Start / Pause / Stop
- Adjustable automation speed
- Local session statistics
- Release build configuration with R8 shrinking
- No analytics, ads, accounts, credentials, or network access

## Build a release APK
1. Open the project in Android Studio.
2. Let Gradle sync.
3. Select **Build > Generate Signed Bundle / APK**.
4. Select **APK**.
5. Create or select your Android signing key.
6. Choose the `release` variant.
7. Build.

The resulting signed APK can be installed on compatible Android devices.

## Important game-specific step
The included rules are examples only. To automate a particular authorized game, edit `AutomationEngine.kt` and implement that game's state/action rules. Do not use the app to bypass anti-cheat, authentication, access controls, or other protections.
